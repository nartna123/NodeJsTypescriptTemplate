
export const PI: number = 3.14;
