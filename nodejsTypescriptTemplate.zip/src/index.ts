import {PI} from "./consts";

function main(): void {
    const hello: string = "Hello, world!"
    console.log("Greeting:", hello);

    console.log("Check export: ", PI);
}

main();
